import pandas as pd, numpy as np, datetime
pd.set_option('display.max_columns', None)

# import os
# test_df = pd.read_csv(os.path.join('data', 'test.csv'))
# print(test_df)
# test_df.to_csv(os.path.join('data', 'test2.csv'), index=False)

from progs import test1, test2
test1.test_func()
test2.test_func2()